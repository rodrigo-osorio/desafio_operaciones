--Parte 2

--9 Crear una nueva tabla, llamada comentarios, con los atributos id, fecha y hora de creación,contenido, que se relacione con la tabla posts.
CREATE TABLE comentarios(
    id_comment INT NOT NULL,
    comment_date TIMESTAMP,
    comment_content VARCHAR(25),
    FOREIGN KEY(id_comment) REFERENCES post(id_post)
);

--10 Crear 2 comentarios para el post de "Pamela" y 4 para "Carlos"
INSERT INTO comentarios(id_comment, comment_date, comment_content) VALUES
(1, '2020-05-23 20:34:40', 'Pamela, excelente post'),
(2, '2020-09-16 15:20:00', 'Hola Pamela, nuevamente');

--11 Crear un nuevo post para "Margarita"
INSERT INTO post(id_post, user_name, post_date, post_content, post_description, post_title) VALUES
(
    7,'Margarita','2020-12-31', 'Hola soy Margarita', 'primer post de Margarita', 'Post#1Margarita'
);

--12 Ingresar 5 comentarios para el post de Margarita.
INSERT INTO comentarios(id_comment, comment_date, comment_content) VALUES
(7, '2020-12-24 23:03:21', 'Comentario 1'),
(7, '2020-01-16 17:30:00', 'Comentario 2'),
(7, '2021-01-03 08:12:02', 'Comentario 3'),
(7, '2019-08-15 19:34:43', 'Comentario 4'),
(7, '2018-03-12 00:01:01', 'Comentario 5');