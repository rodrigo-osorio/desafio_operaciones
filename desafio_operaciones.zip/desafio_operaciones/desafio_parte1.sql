--Parte 1

--1 Crear Base de datos posts
CREATE DATABASE posts;

--2 Crear tabla post, con los atributos id, nombre de usuario, fecha de creación, contenido,descripción 
\c posts;

CREATE TABLE post(
    id_post INT UNIQUE NOT NULL,
    user_name VARCHAR(20) NOT NULL,
    post_date DATE,
    post_content VARCHAR(30), 
    post_description VARCHAR(100),
    PRIMARY KEY (id_post)
);

--3 Insertar 3 post, 2 para el usuario "Pamela" y uno para "Carlos" 
INSERT INTO post(id_post, user_name, post_date, post_content, post_description) VALUES
    (1,'Pamela', '2020-01-18', 'Hola! Soy Pamela', 'primer post de Pamela'),
    (2,'Pamela', '2020-02-01', 'Hola! Soy Pamela nuevamente', 'segundo post de Pamela'),
    (3,'Carlos', '2021-01-21', 'Hola! Soy Carlos', 'primer post de Carlos');

--4 Modificar la tabla post, agregando la columna título
ALTER TABLE post ADD COLUMN post_title VARCHAR(15);

--5 Agregar título a las publicaciones ya ingresadas
UPDATE post SET post_title='Post#1 Pamela' WHERE id_post = 1;
UPDATE post SET post_title='Post#2 Pamela' WHERE id_post = 2;
UPDATE post SET post_title='Post#1 Carlos' WHERE id_post = 3;

--6 Insertar 2 post para el usuario "Pedro"
INSERT INTO post(id_post, user_name, post_date, post_content, post_description, post_title) VALUES
(4,'Pedro', '2021-01-01', 'Hola! Soy Pedro','primer post de Pedro','Post#1 Pedro'),
(5,'Pedro', '2021-01-01', 'Hola! Soy Pedro nuevamente','segundo post de Pedro','Post#2 Pedro');

--7 Eliminar el post de Carlos
DELETE FROM post WHERE id_post = 3;

--8 Ingresar un nuevo post para el usuario "Carlos"
INSERT INTO post(id_post, user_name, post_date, post_content, post_description, post_title) VALUES
(6, 'Carlos', '2021-01-21', 'Hola! Soy Carlos nuevamente', 'segundo post de carlos', 'Post#2 Carlos');


